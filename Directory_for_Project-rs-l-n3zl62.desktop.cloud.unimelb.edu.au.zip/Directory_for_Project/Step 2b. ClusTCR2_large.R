require(STEGO.R)
require(ClusTCR2)

# this process assumes that you have already merged the files using the interface, and saved the file in 2_ClusTCR2 folder in the directory.
merging_ClusTCR2(chain = "AG")
merging_ClusTCR2(chain = "BD")

# alpha/gamma chain
clust.data.raw <- read.csv("2_ClusTCR2/AG_Multi_ClusTCR2.csv")

# this should print the v_gene name
names(clust.data.raw)

# once you have checked the v_gene name matches, proceeded to running the clustering step (1 edit distance), followed by the MCL step to label the clusters.
step1 <- ClusTCR2::ClusTCR_Large(clust.data.raw,allele = F,v_gene = "v_call")
step2 <- ClusTCR2::mcl_cluster_large(step1)

# this saves both the analysis cluster table and the list object that can create each of the unique network plots
saveRDS(step2,"2_ClusTCR2/AG_clusTCR2.all.rds")
# saves the final clustering table for the Step 4. Analysis section.

step2_analysis <- as.data.frame(step2[[1]])
step2_analysis <- step2_analysis[,names(step2_analysis) %in% c("count","Clust_size_order","CDR3_Vgene")]
write.csv(step2_analysis,"4_Analysis/AG_clusTCR2_output.csv",row.names = F)

# beta/delta chain ----
clust.data.raw <- read.csv("2_ClusTCR2/BD_Multi_ClusTCR2.csv")
names(clust.data.raw)[2]
step1 <- ClusTCR2::ClusTCR_Large(clust.data.raw, allele = F, v_gene = "v_call")
step2 <- ClusTCR2::mcl_cluster_large(step1)
saveRDS(step2,"1_ClusTCR/BD_clusTCR2.all.rds") # saves the two list objects

step2_analysis <- as.data.frame(step2[[1]])
step2_analysis <- step2_analysis[,names(step2_analysis) %in% c("count","Clust_size_order","CDR3_Vgene")]

write.csv(step2_analysis,"4_Analysis/BD_clusTCR2_output.csv",row.names = F)
