require(STEGO.R)
# this will only work for 10x at the moment. The BD Rhapsody automation is under development #

# Run this line to check that the files are found before proceeding to automate the pre-processing STEP 1.
# the four files need to be stored in the sub-folder as: barcode, features, matrix and contig.
preprocessing_10x(downloadTCRex = F, downloadClusTCR = F,downloadSeurat = F,downloadTCR_Explore = F,shiny_server = F)

# once that you have made sure the files are in the correct format, all of them will download to their respective folders.
preprocessing_10x(downloadTCRex = T, downloadClusTCR = T,downloadSeurat = T,downloadTCR_Explore = T,shiny_server = F)

# The BD Rhapsody automation
# there are five required files in sub-folders: barcode, features, matrix, sample_tags and contig
preprocessing_bd_rap(downloadTCRex = F, downloadClusTCR = F,downloadSeurat = F,downloadTCR_Explore = F,shiny_server = F)

# once that you have made sure the files are in the correct format, all of them will download to their respective folders.
preprocessing_bd_rap(downloadTCRex = T, downloadClusTCR = T,downloadSeurat = T,downloadTCR_Explore = T,shiny_server = F)
