# see https://stegor.readthedocs.io/en/latest/index.html for more details on the tutorial to follow through.

# make sure that you have installed R, RStudio and the complier from either Quartz or Rtools. Install these before opening R as the changes may not be registered otherwise.

# installing STEGO.R
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

if (!require("devtools", quietly = TRUE))
  install.packages("devtools")

if (!require("usethis", quietly = TRUE))
  install.packages("usethis")

# install this first
install.packages("ClusTCR2")

# Install the devtools package if not already installed
library(devtools)

# install a new way to get the common fonts from your system
install_github("KerryAM-R/fontHelper")

# install STEGO.R with Devtools
# if you get asked about installing from SOURCE, select NO.
# if asked about updating the packages, select either 1 for all, or 3 for none.
# also run this line to check for updates
devtools::install_github("KerryAM-R/STEGO.R")

# installing olga with system2
system2("python", args = c("-m", "pip", "install", "olga"))
