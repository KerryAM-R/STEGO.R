require(STEGO.R)

# use this to run STEGO.R
runSTEGO()
