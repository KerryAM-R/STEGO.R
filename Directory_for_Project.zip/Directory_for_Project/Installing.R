# installing STEGO.R
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

if (!require("devtools", quietly = TRUE))
  install.packages("devtools")

usethis::edit_r_environ()


devtools::install_github("KerryAM-R/STEGO.R")
