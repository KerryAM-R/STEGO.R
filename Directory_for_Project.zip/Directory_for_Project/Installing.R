# see https://stegor-documents.readthedocs.io/en/latest/index.html for more details on the tutorial to follow through.


usethis::edit_r_environ()

# installing STEGO.R
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

if (!require("devtools", quietly = TRUE))
  install.packages("devtools")

if (!require("usethis", quietly = TRUE))
  install.packages("usethis")

# install STEGO.R with Devtools
# if you get asked about installing from SOURCE, select NO.
# if asked about updating the packages, select either 1 for all, or 3 for none.
devtools::install_github("KerryAM-R/STEGO.R")

1
# under development - latest build, but may be unstable
devtools::install_github("KerryAM-R/STEGO.R", ref = "beta-version", force = T)

# you many need to add in the git_token, and the Renviorn is opened with the following code.
usethis::edit_r_environ()

# import all of the fonts to your system. Will only need to be done the first time.
require(extrafont)
font_import()
loadfonts()

fonts <- fonttable()
head(fonts)
