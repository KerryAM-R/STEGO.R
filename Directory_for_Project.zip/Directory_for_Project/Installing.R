# installing STEGO.R

devtools::install_github("KerryAM-R/STEGO.R", force = T)
