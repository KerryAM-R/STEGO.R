# installing STEGO.R
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

if (!require("devtools", quietly = TRUE))
  install.packages("devtools")

usethis::edit_r_environ()
# remotes::install_version("Matrix", version = "1.6-1")
# remotes::install_version("Seurat", version = "4.3.0")
devtools::install_github("KerryAM-R/STEGO.R")

# install the beta-version of STEGO.R -----
remotes::install_github("KerryAM-R/STEGO.R", ref = "beta-version", force = T)
