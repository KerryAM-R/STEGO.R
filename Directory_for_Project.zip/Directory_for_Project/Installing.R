# installing STEGO.R
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

if (!require("devtools", quietly = TRUE))
  install.packages("devtools")

if (!require("usethis", quietly = TRUE))
  install.packages("usethis")

devtools::install_github("KerryAM-R/STEGO.R")

# you many need to add in the git_token, and the Renviorn is opened with the following code.
usethis::edit_r_environ()

# import all of the fonts to your system. Will only need to be done the first time.
require(extrafont)
font_import()
loadfonts()

fonts <- fonttable()
head(fonts)
