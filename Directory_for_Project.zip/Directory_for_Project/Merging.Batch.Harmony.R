require(STEGO.R)
# large file merging and annotating
# as the program window may disappear, we recommend merging and annotating using the following commands

###### merging seurat object ------
merging_multi_SeuratRDS(set_directory = "2_scObj/", merge_RDS = F, pattern_RDS = ".rds$") # Check that you are in the correct working directory with your RDS files
sc_merge <- merging_multi_SeuratRDS(set_directory = "2_scObj/", merge_RDS = T, pattern_RDS = ".rds$") # once that is check, switch merge_RDS to TRUE or T
sc <- JoinLayers(sc_merge,  assay = "RNA") # merges the different layers
saveRDS(sc_merge,"2_scObj/sc_merge.rds") # save the merged file - it will not have the scaled data and PCA stored any more due to the merging process. This is in case R crashes and it needs to be read in


## perform the harmony batch correction ------
sc <- harmony_batch_correction_1_variableFeatures(file = sc)
sc <- harmony_batch_correction_2_Scaling(file = sc, Seruat_version = "V5")
sc <- harmony_batch_correction_3_PC(file = sc)
sc <- harmony_batch_correction_4_Harmony(file = sc)
saveRDS(sc,"2_scObj/sc_harmony.rds")

#### annotating Seurat object -----
sc <- scGate_annotating(file = sc,
                        TcellFunction = T, # switch to T if wa
                        generic = T,
                        stress = T,
                        cycling = T,
                        threshold = 0.2, # change to 0.2 if you use the focused immuen panel from BD rhapsody
                        reductionType = "harmony")

sc@meta.data$Cell_Index_old <- sc@meta.data$Cell_Index
sc@meta.data$Cell_Index <- rownames(sc@meta.data)
head(sc@meta.data)
saveRDS(sc,"3_analysis/sc_anno.rds")


# loading RDS file
sc <- readRDS("path/to/RDS/file")
