require(STEGO.R)

# large file merging and annotating
# as the program window may disappear, we recommend merging and annotating using the following commands

###### merging seurat object ------
# Check that you are in the correct working directory with your RDS files
merging_multi_SeuratRDS(set_directory = "2_scObj/", merge_RDS = F, pattern_RDS = ".rds$")

# once that is check, switch merge_RDS to TRUE or T
sc_merge <- merging_multi_SeuratRDS(set_directory = "2_scObj/", merge_RDS = T, pattern_RDS = ".rds$")
sc_merge

# merges the different layers which is needed for Seurat V5, but not needed for V4.
sc <- JoinLayers(sc_merge,  assay = "RNA")
sc <- sc_merge
rm(sc_merge)
# save the merged file - it will not have the scaled data and PCA stored any more due to the merging process. This is in case R crashes and it needs to be read in
require("lubridate")

saveRDS(sc_merge,paste0("2_scObj/sc_merge_",today(),".rds"))

## perform the harmony batch correction ------
sc <- harmony_batch_correction_1_variableFeatures(file = sc)
sc <- harmony_batch_correction_2_Scaling(file = sc, Seruat_version = "V4")
sc <- harmony_batch_correction_3_PC(file = sc)

sc <- harmony_batch_correction_4_Harmony(file = sc)
sc
saveRDS(sc,paste0("2_scObj/sc_harmony_",today(),".rds"))

#### annotating Seurat object (human) -----
sc <- readRDS("~/Desktop/sc_harmony_2024-03-28.rds")
sc
require(STEGO.R)
sc@assays$RNA@var.features[grep("FUT",sc@assays$RNA@var.features)]
"FUT7" %in% rownames(sc@assays$RNA@counts)

sc@meta.data$TCR <-  ifelse((sc@meta.data$Sample_Name) == "NA","no TCR","TCR")
table(sc@meta.data$TCR)
sc_TCRseq <- subset(sc, subset = TCR == "TCR")
sc_TCRseq

saveRDS(sc_TCRseq,"~/Desktop/sc_harmony_TCRonly_2024-03-28.rds")

sc_TCRseq <- readRDS("~/Desktop/sc_harmony_TCRonly_2024-03-28.rds")
downsc_TCRseq
sc_TCRseq <- scGate_annotating(
          file = sc_TCRseq,
          TcellFunction = T,
          generic = T,
          exhausted = T,
          senescence = T,
          cycling = T,
          Th1_cytokines = T,
          threshold = 0.2, # change to 0.5 if you use the focused immuen panel from BD rhapsody
          reductionType = "harmony",
          TCRseq = T,
          chunk_size = 50000
        )



sc_TCRseq@meta.data$Cell_Index_old <- sc_TCRseq@meta.data$Cell_Index
sc_TCRseq@meta.data$Cell_Index <- rownames(sc_TCRseq@meta.data)
head(sc@meta.data)
saveRDS(sc,"3_analysis/sc_anno.rds")
rownames(sc@assays$RNA@scale.data)
# loading RDS file
sc <- readRDS("path/to/RDS/file")
