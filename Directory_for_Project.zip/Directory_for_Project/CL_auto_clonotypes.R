
require(STEGO.R)

# automating pipeline for the clonotypes
sc <- readRDS("3_analysis/sc_anno.rds")
updateID <- read.csv("3_analysis/Update_labels.csv")

sc <- update_sc(sc, updateID = updateID)
saveRDS(sc,"3_analysis_updated.rds")

# save teh Upset overlap and the corresponding file
Upset_plot_multi(sc, save_plots = T)

# save a bar graph of the clonal expansion; default is the frequencies rather than count.
clonal_plot_multi(sc, save_file = T)

# automated function for find marker, dotplot and over-rep analysis
Clonotypes_PublicLike(sc)

# in progress the clonotypes_private function
