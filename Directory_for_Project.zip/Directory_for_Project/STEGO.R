
# use this to run STEGO.R
STEGO.R::runSTEGO()
