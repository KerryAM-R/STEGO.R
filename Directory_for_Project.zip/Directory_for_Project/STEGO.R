
STEGO.R::Load_required_packages()
STEGO.R::runSTEGO()
